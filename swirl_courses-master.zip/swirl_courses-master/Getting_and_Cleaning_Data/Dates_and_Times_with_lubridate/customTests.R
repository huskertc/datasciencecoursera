func_uses_args <- function(...) {
  e <- get("e", parent.frame())
  # Get user's expression
  expr <- e$expr
  # Capture names of correct args
  correct_args <- list(...)
  # If expr is assignment, just get the rhs
  if(is(expr, "<-")) expr <- expr[[3]]
  # Check for the presence of each correct arg in the expr names
  match_found <- try(sapply(correct_args, function(arg) arg %in% names(expr)))
  # If something is weird, return FALSE
  if(!all(is.logical(match_found))) {
    return(FALSE)
  }
  # Did we find all desired args?
  all(match_found)
}

match_call <- function(correct_call = NULL) {
  e <- get("e", parent.frame())
  # Trivial case
  if(is.null(correct_call)) return(TRUE)
  # Get full correct call
  full_correct_call <- expand_call(correct_call)
  # Expand user's expression
  expr <- deparse(e$expr)
  full_user_expr <- try(expand_call(expr), silent = TRUE)
  # Check if expansion went okay
  if(is(full_user_expr, "try-error")) return(FALSE)
  # Compare function calls with full arg names
  identical(full_correct_call, full_user_expr)
}

# Utility function for match_call answer test
# Fills out a function call with full argument names
expand_call <- function(call_string) {
  # Quote expression
  qcall <- parse(text=call_string)[[1]]
  # If expression is not greater than length 1...
  if(length(qcall) <= 1) return(qcall)
  # See if it's an assignment
  is_assign <- is(qcall, "<-")
  # If assignment, process righthandside
  if(is_assign) {
    # Get righthand side
    rhs <- qcall[[3]]
    # If righthand side is not a call, can't use match.fun()
    if(!is.call(rhs)) return(qcall)
    # Get function from function name
    fun <- match.fun(rhs[[1]])
    # match.call() does not support primitive functions
    if(is.primitive(fun)) return(qcall)
    # Get expanded call
    full_rhs <- match.call(fun, rhs)
    # Full call
    qcall[[3]] <- full_rhs
  } else { # If not assignment, process whole thing
    # Get function from function name
    fun <- match.fun(qcall[[1]])
    # match.call() does not support primitive functions
    if(is.primitive(fun)) return(qcall)
    # Full call
    qcall <- match.call(fun, qcall)
  }
  # Return expanded function call
  qcall
}

test_arrive_val <- function() {
  # Get user's value
  e <- get('e', parent.frame())
  user_val <- e$val
  # Get correct value
  depart <- get('depart', globalenv())
  correct_val <- depart + hours(15) + minutes(50)
  # Compare
  identical(user_val, correct_val)
}

start_timer <- function() {
  e <- get('e', parent.frame())
  e$`__lesson_start_time` <- now()
  TRUE
}

stop_timer <- function() {
  e <- get('e', parent.frame())
  if(deparse(e$expr) == "stopwatch()") {
    start_time <- e$`__lesson_start_time`
    stop_time <- now()
    print(as.period(new_interval(start_time, stop_time)))
  }
  TRUE
}
