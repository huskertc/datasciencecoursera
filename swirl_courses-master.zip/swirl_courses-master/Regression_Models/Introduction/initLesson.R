# Put initialization code in this file.
galton <- read.csv(file.path(find.package("swirl"), "Courses/Regression_Models/Introduction", "galton.csv"))